using UnityEngine;

public static class Reverse
{
    public static bool Enable { get; set; }
}
