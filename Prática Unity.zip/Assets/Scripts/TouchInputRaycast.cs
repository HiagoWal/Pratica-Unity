using UnityEngine;
using UnityEngine.InputSystem.EnhancedTouch;

public class TouchInputRaycast : MonoBehaviour
{
    private PlayerMovement playerMovement;

    void Start()
    {
        playerMovement = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMovement>();
    }




    void Update()
    {
        if (Input.touchCount > 0)
        {
            foreach (UnityEngine.Touch touch in Input.touches)
            {
                Vector2 worldpoint = Camera.main.ScreenToWorldPoint(touch.position);

                RaycastHit2D hit = Physics2D.Raycast(worldpoint, Vector2.zero);

                // Chama SetMoveDirection enquanto o dedo está pressionando/movendo
                if (touch.phase == TouchPhase.Began ||
                    touch.phase == TouchPhase.Moved ||
                    touch.phase == TouchPhase.Stationary)
                {
                    if (hit.collider != null)
                    {
                        string tag = hit.collider.tag;

                        switch (tag)
                        {
                            case "Reverse":
                                Reverse.Enable = !Reverse.Enable;
                                break;
                            case "Up":
                                playerMovement.SetMoveDirection(Vector2.up);
                                break;
                            case "Down":
                                playerMovement.SetMoveDirection(Vector2.down);
                                break;
                            case "Left":
                                playerMovement.SetMoveDirection(Vector2.left);
                                break;
                            case "Right":
                                playerMovement.SetMoveDirection(Vector2.right);
                                break;
                        }
                    }
                }

                if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
                {
                    playerMovement.StopMove();
                }
            }
        }
#if UNITY_EDITOR
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 worldpoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            RaycastHit2D hit = Physics2D.Raycast(worldpoint, Vector2.zero);

            if (hit.collider != null)
            {
                string tag = hit.collider.tag;

                switch (tag)
                {
                    case "Up":
                        playerMovement.SetMoveDirection(Vector2.up);
                        break;
                    case "Down":
                        playerMovement.SetMoveDirection(Vector2.down);
                        break;
                    case "Left":
                        playerMovement.SetMoveDirection(Vector2.left);
                        break;
                    case "Right":
                        playerMovement.SetMoveDirection(Vector2.right);
                        break;
                }
            }
        }

        if (Input.GetMouseButtonUp(0))
        {
            playerMovement.StopMove();
        }
#endif
    }
}