using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float walkSpeed = 3f;

    private Rigidbody2D rb;
    private Animator animatorCharacter;
    private Vector2 moveInput;
    
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animatorCharacter = GetComponent<Animator>();   
    }

    
    void Update()
    {
        animatorCharacter.SetFloat("MoveX", moveInput.x);
        animatorCharacter.SetFloat("MoveY", moveInput.y);
        animatorCharacter.SetBool("isMoving", moveInput != Vector2.zero);
    }

    void FixedUpdate()
    {
        rb.linearVelocity = moveInput * walkSpeed;
    }

    public void SetMoveDirection (Vector2 direction)
    {
        moveInput = direction;
    }

    public void StopMove()
    {
        moveInput = Vector2.zero;
    }
}
