using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float walkSpeed = 3f;

    private Rigidbody2D rb;
    private Animator animatorCharacter;
    private Vector2 moveInput;

    private enum InputType { None, Keyboard, Touch }
    private InputType lastInput = InputType.None;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animatorCharacter = GetComponent<Animator>();
    }

    void Update()
    {
        float moveX = Input.GetAxisRaw("Horizontal");
        float moveY = Input.GetAxisRaw("Vertical");

        // Teclado tem prioridade se pressionado
        if (moveX != 0 || moveY != 0)
        {
            moveInput = new Vector2(moveX, moveY).normalized;
            lastInput = InputType.Keyboard;
        }
        // Se não houver teclado, mas houver touch, mantém moveInput do touch
        else if (Input.touchCount > 0 && lastInput == InputType.Touch)
        {
            // moveInput já foi atualizado pelo touch
        }
        // Se nenhum input, para
        else if (moveX == 0 && moveY == 0 && Input.touchCount == 0)
        {
            moveInput = Vector2.zero;
            lastInput = InputType.None;
        }

        // Atualize sempre os parâmetros do Animator com base em moveInput
        if (moveInput == Vector2.zero)
        {
            animatorCharacter.SetBool("isIdle", true);
            animatorCharacter.SetBool("isMovingRight", false);
            animatorCharacter.SetBool("isMovingLeft", false);
            animatorCharacter.SetBool("isMovingUp", false);
            animatorCharacter.SetBool("isMovingDown", false);
        }
        else
        {
            animatorCharacter.SetBool("isIdle", false);
            animatorCharacter.SetBool("isMovingRight", moveInput.x > 0);
            animatorCharacter.SetBool("isMovingLeft", moveInput.x < 0);
            animatorCharacter.SetBool("isMovingUp", moveInput.y > 0);
            animatorCharacter.SetBool("isMovingDown", moveInput.y < 0);
        }
    }

    void FixedUpdate()
    {
        rb.linearVelocity = moveInput * walkSpeed;
    }

    public void SetMoveDirection(Vector2 direction)
    {
        moveInput = direction;
        lastInput = InputType.Touch;
    }

    public void StopMove()
    {
        if (lastInput == InputType.Touch)
        {
            moveInput = Vector2.zero;
            lastInput = InputType.None;
        }
    }
}
